import * as bootstrap from 'bootstrap'

export { bootstrap }
